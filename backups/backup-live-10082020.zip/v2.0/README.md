ABOUT:
    ADD TEAM IMAGE

MENU:
    DESSERTS MISSING
    
ADMIN:
    ADD ADMIN PAGE WITH INFO ADMINSTRATION FOR THE SITE
    
EVENTS:
    ADD EVENTS PAGE WITH INFO ON EVENTS






















/* SMALL PHONE */
@media only screen and (min-width: 320px) {}

/* MEDIUM PHONE */
@media only screen and (min-width: 375px) {}

/* LARGE PHONE */
@media only screen and (min-width: 425px) {}

/* TABLET */
@media only screen and (min-width: 768px) {}

/* LAPTOP */
@media only screen and (min-width: 1024px) {}

/* DESKTOP */
@media only screen and (min-width: 1440px) {}